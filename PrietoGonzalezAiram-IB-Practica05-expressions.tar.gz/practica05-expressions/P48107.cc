/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica 2022-2023
 *
 * @file P48107 C++
 * @author Airam Prieto González
 * @date Nov 1 2022
 * @brief El programa toma los valores de dos enteros y muestra los resultados
 * de su division ademas del resto de esta
 * de todas sus operaciones 
 * @bug There are no known bugs
 * @see https://jutge.org/problems/P48107
 */


#include <iostream>

int main () {
  std::cout<<"Introduzca dos números enteros para operar"<<std::endl;
  int valor1;
  std::cin>> valor1;
  int valor2;
  std::cin>> valor2;
  std::cout<<"Los resultados son:"<<std::endl;
  std::cout<<valor1<< " / "<<valor2<<" = "<<valor1 / valor2<<std::endl;
  std::cout<<valor1<<"El resto de la operación es: "<<valor1 % valor2<<std::endl;
}
