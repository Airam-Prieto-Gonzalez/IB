/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Informática Básica 2022-2023
*
* @author Airam Prieto González
* @date Oct 30 2022
* @brief El programa toma la mayúscula introducida y la convierte en minúscula
* @bug There are no known bugs
* @see https://jutge.org/problems/P48107
*/

#include <iostream>
 
int main () {
  int cifra1;
  std::cin>>cifra1;
  int cifra2;
  std::cin>>cifra2;
  int cifra3;
  std::cin>>cifra3;

  if (cifra1 > cifra2 > cifra3) {
    std::cout<< cifra1<<std::endl;
  }
  else if (cifra2 > cifra1 > cifra3) {
    std::cout<< cifra2 <<std::endl;
  }
  else {
    std::cout<< cifra3 <<std::endl;
  }
 }

