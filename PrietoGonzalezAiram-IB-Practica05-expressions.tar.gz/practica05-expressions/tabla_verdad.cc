/**
  2  * Universidad de La Laguna
  3  * Escuela Superior de Ingeniería y Tecnología
  4  * Grado en Ingeniería Informática
  5  * Informática Básica 2022-2023
  6  *
  7  * @file operadores aritméticos C++
  8  * @author Airam Prieto González
  9  * @date Nov 1 2022
 10  * @brief El programa toma los valores de dos enteros y muestra los resultados
 11  * de todas sus operaciones 
 12  * @bug There are no known bugs
 13  * @see https://jutge.org/problems/P48107
 14  */
 


#include <iostream>

int main () {
  std::cout<<"Tabla de verdad, introduzca 1 (true) o 0 (false)"<<std::endl;
  bool elemento1;
  std::cin>> elemento1;
  bool elemento2;
  std::cin>> elemento2;
  std::cout<<"elemento1 "<<elemento1<<std::endl;
  std::cout<<"no elemento1 "<<!elemento1<<std::endl;
  std::cout<<"elemento1 "<<elemento2<<std::endl;
  std::cout<<"no elemento1 "<<!elemento2<<std::endl;
  if (elemento1 == 1 && elemento2 == 1) {
    std::cout<<"elemento1 Y elemento2 1"<<std::endl;
  }
  else {
    std::cout<<"elemento1 Y elemento2 0"<<std::endl;
  }
  if (elemento1 == 1 || elemento2 == 1) {
    std::cout<<"elemento1 O elemento2 1"<<std::endl;
  }
  else {
    std::cout<<"elemento1 Y elemento2 0"<<std::endl;
  }
   
}


