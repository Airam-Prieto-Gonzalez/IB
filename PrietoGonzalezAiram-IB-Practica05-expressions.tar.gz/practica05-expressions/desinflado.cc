/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Informática Básica 2022-2023
*
* @file Desinflado C++
* @author Airam Prieto González
* @date Oct 30 2022
* @brief El programa toma la mayúscula introducida y la convierte en minúscula
* @bug There are no known bugs
* @see https://jutge.org/problems/P48107
*/

#include <iostream>
 
 int main () {
 char letra1;
 std::cout<<"Por favor, introduzca una mayuscula para convertirla en minúscula"<<std::endl;
 std::cin>>letra1;
 int letra2 {static_cast<int>(letra1) + 32};
 std::cout<< static_cast<char>(letra2)<<std::endl;
 }


